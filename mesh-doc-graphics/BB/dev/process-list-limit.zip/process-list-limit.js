require('mesh-base');
//..............................................................................
const {cloud, fs, path, httpClient, logger, util} = cxq;
//..............................................................................

//..............................................................................
const
{
    abort,
    shutdown,
    wait,
    processList,
    processListParallel,
    processListSerial,
    processListLimit,
    meshNowMs,
} = util;
//..............................................................................

//..............................................................................
const log = logger('process-list-limit');
log.setLevel('info');
//..............................................................................

//..............................................................................
const testData =
[
    {caption:'Test-000', number:1},
    {caption:'Test-001', number:2},
    {caption:'Test-002', number:3},
    {caption:'Test-003', number:4},
    {caption:'Test-004', number:5},
    {caption:'Test-005', number:6},
    {caption:'Test-006', number:7},
    {caption:'Test-007', number:8},
];
//..............................................................................

//..............................................................................
function runTest(mainCallback)
{
    const startTime = meshNowMs();
    //..........................................................................
    function processSingle(single, callback)
    {
        log.info('processSingle:', single.caption, single.number);
        //......................................................................
        function singleDone()
        {
            const elapsed = meshNowMs() - startTime;
            log.info('Complete:',single.caption, single.number, 'Elapsed:',elapsed);
            callback(null);
        }
        ////////////////////////////////////////////////////////////////////////
        wait(single.number*100).then(singleDone);
    }
    //..........................................................................
    function allDone(err)
    {
        log.info('All-Done');
        mainCallback(err);
    }
    ////////////////////////////////////////////////////////////////////////////
    processListLimit(testData, 3, processSingle, allDone)
}
//..............................................................................

runTest(function(err)
{
    shutdown();
});
