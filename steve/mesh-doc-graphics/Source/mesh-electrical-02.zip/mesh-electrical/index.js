require ('mesh-base');

//..............................................................................
const {util} = cxq;
const {} = util;
//..............................................................................

//..............................................................................
const definitionMB0001 = require('./MB0001');
const definitionMB0016 = require('./MB0016');
const {makeElectronicComponent} = require('./components');
//..............................................................................

const MB0001 = makeElectronicComponent(definitionMB0001);
const MB0016 = makeElectronicComponent(definitionMB0016);
MB0001.dump();
MB0016.dump();

console.log('getPinById:MB0001.GND:', MB0001.getPinById ('GND'));
console.log('getPinByRef:MB0001.F12', MB0001.getPinByRef('F12'));

console.log('getPinById:MB0016.GND:', MB0016.getPinById ('GND'));
console.log('getPinByRef:MB0016.F12', MB0016.getPinByRef('F12'));

console.log('MB0001:', MB0001.id, 'pinCount:', MB0001.pinCount);
console.log('MB0016:', MB0016.id, 'pinCount:', MB0016.pinCount);
