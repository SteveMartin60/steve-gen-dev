//..............................................................................
const {util, getPinType} = cxq;
const
{
    deepClone,
    mergeObjectDeep,
    processList,
    padRight,
    objectToArray,
    functionAsProperty_ReadOnly,
    propertyCount,
} = util;
//..............................................................................

const polarityShort = {'+':'+ve', '-':'-ve'};
const polarityLong  = {'+':'positive', '-':'negative'};

//..............................................................................
function expandPinDefinition(component)
{
    function processSinglePin(pin)
    {
        pin.pin_type = pin.pin_type || 'passive';

        const pinType = getPinType(pin.pin_type);
        if (!pinType)
        {
            console.log('ERROR: Unknown Pin-Type:',pin.pin_type, pin);
            process.exit();
        }

        if (pin.pin_type === 'gpio')
        {
            pin.caption_en = pin.id;
            pin.caption_zh = pin.id;
        }

        pin.id       = pin.id || pinType.default_name    || pinType.id;
        pin.pin_type =           pinType.electrical_type || pinType.id;

        pin.caption_en     = pin.caption_en     || pinType.caption_en;
        pin.caption_zh     = pin.caption_zh     || pinType.caption_zh;
        pin.description_en = pin.description_en || pinType.description_en;
        pin.description_zh = pin.description_zh || pinType.description_zh;
    }
    ////////////////////////////////////////////////////////////////////////////
    processList(component.pins, processSinglePin);
}
//..............................................................................


//..............................................................................
function parsePinList(listString)
{
    function cleanupId(id)
    {
        return id.trim();
    }
    ////////////////////////////////////////////////////////////////////////////
    return listString.split(',').map(cleanupId);
}
//..............................................................................

//..............................................................................
function makeElectronicComponent(definition)
{
    const fullList      = [];
    const pinRefLookup  = {};
    const pinNameLookup = {};
    //..........................................................................
    function processPinDefinition(defintion)
    {
        const {id, pin_type, caption_en, description_en} = defintion;
        const refs = parsePinList(defintion.refs);
        processList(refs, function(ref)
        {
            const fullPin = mergeObjectDeep({}, {ref}, defintion);
            delete fullPin.refs;
            fullList.push(fullPin);
            pinRefLookup[ref] = fullPin;
            pinNameLookup[id] = pinNameLookup[id] || [];
            pinNameLookup[id].push(fullPin);
        })
    }
    //..........................................................................
    function getPinById(id)
    {
        return pinNameLookup[id] || null;
    }
    //..........................................................................
    function getPinByRef(ref)
    {
        return pinRefLookup[ref] || null;
    }
    //..........................................................................
    function getAllPins(id)
    {
        return objectToArray( pinRefLookup[id]);
    }
    //..........................................................................
    function dump()
    {
        console.log();
        console.log('-------------------------------------------------------------------------------------------');
        console.log(padRight(definition.id + '-Pins',22),      'Electrical         Caption                  Description');
        console.log('-------------------------------------------------------------------------------------------');
        processList(pinRefLookup, function(single)
        {
            const {ref, id, pin_type, caption_en, description_en} = single;
            console.log(padRight(ref,3), padRight(id,18), padRight(pin_type,18), padRight(caption_en,24), description_en);
        });
        console.log('-------------------------------------------------------------------------------------------');
    }
    ////////////////////////////////////////////////////////////////////////////
    expandPinDefinition(definition);
    processList(definition.pins, processPinDefinition);

    const publicScope =
    {
        getPinById,
        getPinByRef,
        getAllPins,
        dump
    };
    functionAsProperty_ReadOnly(publicScope, function(){return definition.id;}, 'id');
    functionAsProperty_ReadOnly(publicScope, function(){return propertyCount(fullList)}, 'pinCount');
    return publicScope;
}
//..............................................................................

module.exports = {polarityShort,polarityLong, makeElectronicComponent};
