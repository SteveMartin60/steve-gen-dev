//..............................................................................
const definition =
{
  id        : 'MB0016',
  footprint : 'MB-10X14',
  pins : 
  [
    {                       refs: 'A6,  A7,  A8, B6, B7, B8, ' +
                                  'C12, C13, D1, D2, E1, E2, ' +
                                  'EP, F12, G13, H8, H9, J8, J9'   , pin_type: 'ground'      },
    { id: '3V3_OUT'       , refs: 'A12, A13, B12, B13'             , pin_type: 'provider_3V3'},
    { id: '5V0_OUT'       , refs: 'H12, H13, J12, J13'             , pin_type: 'provider_5V' },
    { id: '5V_IN'         , refs: 'A1, A2, A3, B1, B2, B3'         , pin_type: 'power_consumer' , caption_en: '5V Power-In'          , description_en: '5V Power Input'                          , caption_zh:'', description_zh:''},
    { id: 'VA_IN'         , refs: 'G1, G2, H1, H2, J1, J2'         , pin_type: 'power_consumer' , caption_en: 'VA Power-In'          , description_en: 'Power Input A, 5-18V'                    , caption_zh:'', description_zh:''},
    { id: 'VB_IN'         , refs: 'H3, H4, H5, J3, J4, J5'         , pin_type: 'power_consumer' , caption_en: 'VB Power-In'          , description_en: 'Power Input B, 5-18V'                    , caption_zh:'', description_zh:''},
    { id: 'EN_3V3_OUT'    , refs: 'B5'                             , pin_type: 'digital_in'     , caption_en: 'Enable 3V3'           , description_en: 'Enable 3V3 output'                       , caption_zh:'', description_zh:''},
    { id: 'EN_5V_OUT'     , refs: 'J7'                             , pin_type: 'digital_in'     , caption_en: 'Enable 5V'            , description_en: 'Enable 5V output'                        , caption_zh:'', description_zh:''},
    { id: 'LED_3V3_OUT'   , refs: 'D12'                                                         , caption_en: 'LED 3V3 Out'          , description_en: 'LED driver for enable 3V3 output'        , caption_zh:'', description_zh:''},
    { id: 'LED_5V_OUT'    , refs: 'E12'                                                         , caption_en: 'LED 5V Out'           , description_en: 'LED driver for enable 5V output'         , caption_zh:'', description_zh:''},
    { id: 'DET_VA_IN'     , refs: 'F2'                             , pin_type: 'digital_out'    , caption_en: 'VA Input Detect'      , description_en: 'VA power input detection'                , caption_zh:'', description_zh:''},
    { id: 'DET_VB_IN'     , refs: 'H6'                             , pin_type: 'digital_out'    , caption_en: 'VB Input Detect'      , description_en: 'VB power input detection'                , caption_zh:'', description_zh:''},
    { id: 'DET_5V_IN'     , refs: 'C2'                             , pin_type: 'digital_out'    , caption_en: '5V Input Detect'      , description_en: '5V power input detection'                , caption_zh:'', description_zh:''},
    { id: 'LED_VA_IN'     , refs: 'F1'                             , pin_type: 'digital_out'    , caption_en: 'LED VA Input Detect'  , description_en: 'LED driver for VA power input detection' , caption_zh:'', description_zh:''},
    { id: 'LED_VB_IN'     , refs: 'J6'                             , pin_type: 'digital_out'    , caption_en: 'LED VB Input Detect'  , description_en: 'LED driver for VB power input detection' , caption_zh:'', description_zh:''},
    { id: 'LED_5V_IN'     , refs: 'C1'                             , pin_type: 'digital_out'    , caption_en: 'LED 5V Input Detect'  , description_en: 'LED driver for 5V power input detection' , caption_zh:'', description_zh:''},
    { id: 'GOOD_3V3_OUT_N', refs: 'A5'                             , pin_type: 'digital_out'    , caption_en: 'Good 3V3 Out'         , description_en: 'Indicates good 3V3 output'               , caption_zh:'', description_zh:''},
    { id: 'GOOD_5V_OUT_N' , refs: 'H7'                             , pin_type: 'digital_out'    , caption_en: 'Good 5V Out'          , description_en: 'Indicates good 5V output'                , caption_zh:'', description_zh:''},
    { id: '3V3_TO_5V_N'   , refs: 'D13'                            , pin_type: 'passive'        , caption_en: '3V3 To 5V'            , description_en: 'Force 3V3 output to 5V'                  , caption_zh:'', description_zh:''},
    { id: '5V0_TO_3V3'    , refs: 'G12'                            , pin_type: 'passive'        , caption_en: '5V To 3V3'            , description_en: 'Force 5V output to 3V3'                  , caption_zh:'', description_zh:''},
    { id: 'FB_3V3_OUT'    , refs: 'E13'                            , pin_type: 'passive'        , caption_en: '3V3 Adjust'           , description_en: '3V3 regulator adjust - Advanced use only', caption_zh:'', description_zh:''},
    { id: 'FB_5V_OUT'     , refs: 'F13'                            , pin_type: 'passive'        , caption_en: '5V Adjust'            , description_en: '5V regulator adjust - Advanced use only' , caption_zh:'', description_zh:''},
  ]
};
//..............................................................................

module.exports = definition;
