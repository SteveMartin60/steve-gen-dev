//..............................................................................
const {util} = cxq;
const {} = util;
//..............................................................................

//..............................................................................
const {polarityShort,polarityLong} = require('./components');
//..............................................................................

//..............................................................................
function cap_en_VCOIL(n          ) {return 'Coil-Protect '  + n;}
function cap_en_DRIVE(n          ) {return 'Coil-Drive '    + n;}
function cap_en_LOAD (n, polarity) {return 'Relay-Load '    + n + ' ' + polarityShort[polarity]}
function des_en_VCOIL(n          ) {return 'Protection - Attach to coil ' + n + ' high side';}
function des_en_DRIVE(n          ) {return 'Driver - Attach to coil '     + n + ' low side';}
function des_en_LOAD (n, polarity) {return 'Attach to '   + polarityLong[polarity] + ' side of relay load ' +n}
//..............................................................................

//..............................................................................
const definition =
{
  id : 'MB0001',
  footprint : 'MB-10X14',
  pins : 
  [
    {                       refs: 'A10, B10',                   pin_type: 'consumer_3V3'},
    {                       refs: 'C12, E12, E13, H4, H9, H10', pin_type: 'ground'      },
    {                       refs: 'E2'                        , pin_type: 'wake_out'    },
    {                       refs: 'F2'                        , pin_type: 'wake_in'     },
    {                       refs: 'D12'                       , pin_type: 'reset_n'     },
    {                       refs: 'B7'                        , pin_type: 'mosi_slave'  },
    {                       refs: 'A7'                        , pin_type: 'miso_slave'  },
    {                       refs: 'B6'                        , pin_type: 'sclk_slave'  },
    {                       refs: 'A6'                        , pin_type: 'cs_n_slave'  },
    {                       refs: 'B5'                        , pin_type: 'swdio'       },
    {                       refs: 'A5'                        , pin_type: 'swclk'       },
    { id: 'A0/PWM/ADC/DAC', refs: 'F1'                        , pin_type: 'gpio'        },
    { id: 'A1/PWMX/ADC',    refs: 'J8'                        , pin_type: 'gpio'        },
    { id: 'A2/PWMX/ADC',    refs: 'H8'                        , pin_type: 'gpio'        },
    { id: 'A3/PWMX/ADC',    refs: 'J7'                        , pin_type: 'gpio'        },
    { id: 'A4/PWMX/ADC',    refs: 'H7'                        , pin_type: 'gpio'        },
    { id: 'A5/PWMX',        refs: 'J6'                        , pin_type: 'gpio'        },
    { id: 'A6/PWM',         refs: 'E1'                        , pin_type: 'gpio'        },
    { id: 'LOAD0+',         refs: 'G1, G2, H1, J1'            , caption_en: cap_en_LOAD (0, '+'), description_en: des_en_LOAD (0, '+'), caption_zh:'', description_zh:''},
    { id: 'LOAD0-',         refs: 'H2, H3, J2, J3'            , caption_en: cap_en_LOAD (0, '-'), description_en: des_en_LOAD (0, '-'), caption_zh:'', description_zh:''},
    { id: 'LOAD1+',         refs: 'A2, A3, B2, B3'            , caption_en: cap_en_LOAD (1, '+'), description_en: des_en_LOAD (1, '+'), caption_zh:'', description_zh:''},
    { id: 'LOAD1-',         refs: 'A1, B1, C1, D1'            , caption_en: cap_en_LOAD (1, '-'), description_en: des_en_LOAD (1, '-'), caption_zh:'', description_zh:''},
    { id: 'LOAD2+',         refs: 'A13, B13, C13, D13'        , caption_en: cap_en_LOAD (2, '+'), description_en: des_en_LOAD (2, '+'), caption_zh:'', description_zh:''},
    { id: 'LOAD2-',         refs: 'A11, A12, B11, B12'        , caption_en: cap_en_LOAD (2, '-'), description_en: des_en_LOAD (2, '-'), caption_zh:'', description_zh:''},
    { id: 'LOAD3+',         refs: 'H11, H12, J11, J12'        , caption_en: cap_en_LOAD (3, '+'), description_en: des_en_LOAD (3, '+'), caption_zh:'', description_zh:''},
    { id: 'LOAD3-',         refs: 'F13, G13, H13, J13'        , caption_en: cap_en_LOAD (3, '-'), description_en: des_en_LOAD (3, '-'), caption_zh:'', description_zh:''},
    { id: 'VCOIL0',         refs: 'B4'                        , caption_en: cap_en_VCOIL(0     ), description_en: des_en_VCOIL(0     ), caption_zh:'', description_zh:''},
    { id: 'VCOIL1',         refs: 'D2'                        , caption_en: cap_en_VCOIL(1     ), description_en: des_en_VCOIL(1     ), caption_zh:'', description_zh:''},
    { id: 'VCOIL2',         refs: 'H5'                        , caption_en: cap_en_VCOIL(2     ), description_en: des_en_VCOIL(2     ), caption_zh:'', description_zh:''},
    { id: 'VCOIL3',         refs: 'J4'                        , caption_en: cap_en_VCOIL(3     ), description_en: des_en_VCOIL(3     ), caption_zh:'', description_zh:''},
    { id: 'VCOIL4',         refs: 'B9'                        , caption_en: cap_en_VCOIL(4     ), description_en: des_en_VCOIL(4     ), caption_zh:'', description_zh:''},
    { id: 'VCOIL5',         refs: 'A9'                        , caption_en: cap_en_VCOIL(5     ), description_en: des_en_VCOIL(5     ), caption_zh:'', description_zh:''},
    { id: 'VCOIL6',         refs: 'J10'                       , caption_en: cap_en_VCOIL(6     ), description_en: des_en_VCOIL(6     ), caption_zh:'', description_zh:''},
    { id: 'VCOIL7',         refs: 'F12'                       , caption_en: cap_en_VCOIL(7     ), description_en: des_en_VCOIL(7     ), caption_zh:'', description_zh:''},
    { id: 'D0',             refs: 'A4'                        , caption_en: cap_en_DRIVE(0     ), description_en: des_en_DRIVE(0     ), caption_zh:'', description_zh:''},
    { id: 'D1',             refs: 'C2'                        , caption_en: cap_en_DRIVE(1     ), description_en: des_en_DRIVE(1     ), caption_zh:'', description_zh:''},
    { id: 'D2',             refs: 'H6'                        , caption_en: cap_en_DRIVE(2     ), description_en: des_en_DRIVE(2     ), caption_zh:'', description_zh:''},
    { id: 'D3',             refs: 'J5'                        , caption_en: cap_en_DRIVE(3     ), description_en: des_en_DRIVE(3     ), caption_zh:'', description_zh:''},
    { id: 'D4',             refs: 'B8'                        , caption_en: cap_en_DRIVE(4     ), description_en: des_en_DRIVE(4     ), caption_zh:'', description_zh:''},
    { id: 'D5',             refs: 'A8'                        , caption_en: cap_en_DRIVE(5     ), description_en: des_en_DRIVE(5     ), caption_zh:'', description_zh:''},
    { id: 'D6',             refs: 'J9'                        , caption_en: cap_en_DRIVE(6     ), description_en: des_en_DRIVE(6     ), caption_zh:'', description_zh:''},
    { id: 'D7',             refs: 'G12'                       , caption_en: cap_en_DRIVE(7     ), description_en: des_en_DRIVE(7     ), caption_zh:'', description_zh:''},
  ]
};
//..............................................................................

module.exports = definition;

